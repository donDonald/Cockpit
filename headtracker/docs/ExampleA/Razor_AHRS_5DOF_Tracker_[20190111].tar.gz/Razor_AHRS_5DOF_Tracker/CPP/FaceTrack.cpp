/* This file is part of the Razor AHRS Firmware */
//==============================================//

typedef struct
{
  int16_t  Begin;	  		// 2  Debut
  uint16_t Cpt ;     		// 2  Compteur trame or Code info or error
  float    YPR[3];			// 12 [Y, P, R]    gyro
  float    XYZ[3];   		// 12 [x, y, z]    Acc
  int16_t  End ;     		// 2  Fin
} type_hat;

type_hat hat;

float _Yaw    = 0;

#define centerYaw				0
#define centerYawPitch	1
#define centerYPR				2
//================================================
void CenterYP(float MM[3][3], float DCM[3][3], char	OM[3][3]) // result in MM
{
	float M[3][3];
  float half_roll = 0.5f * atan2(MM[2][1], MM[2][2]);	// half of roll;
  //----------
	IdentityMatrix(M);
	Matrix_Multiply(M, OM, MM);			//a*b=c
  //----------
  float qw = cos(half_roll);
  float qx = sin(half_roll);
  //---------- QuaternionToMatrix
	IdentityMatrix(M);
  float xx = qx * qx;
  float xw = qx * qw;
  //----------
  M[1][1] = 1 - 2 * xx;
  M[2][1] =   - 2 * xw;
  M[1][2] =     2 * xw;
  M[2][2] = 1 - 2 * xx;
  //----------
	float M0[3][3];
  Matrix_Multiply(MM, M, M0);
  Matrix_Multiply(DCM, M0, MM);
}
//================================================
void FixCenter()
{
	float MM[3][3];
  //--- head center ---
	Center.ZeroYaw = YPR_head[0] + Center.ZeroYaw;
  Matrix_Multiply(DCM_head, Calibr.D.orient_matrix, MM);
  //----------
  if (Calibr.D.center_mode == 1)			//Center YP
    CenterYP(MM, DCM_head, Calibr.D.orient_matrix);
  //----------- Center_Matrix = MM' --------------
  for(int x=0; x<3; x++) for(int y=0; y<3; y++) Center.Matrix[x][y] = MM[y][x];

  //--- neck center ---
  Matrix_Multiply(DCM_neck, Calibr.D.orientN_matrix, MM);
  //----------
  if (Calibr.D.centerN_mode == 1)		//Center YP
    CenterYP(MM, DCM_neck, Calibr.D.orientN_matrix);
  //----------- Center_Matrix = MM' --------------
  for(int x=0; x<3; x++) for(int y=0; y<3; y++) Center.MatrixN[x][y] = MM[y][x];
}
//================================================
void ResetCenterMatrix()
{
	Center.ZeroYaw = 0.0f;
	IdentityMatrix(Center.Matrix);
	IdentityMatrix(Center.MatrixN);
}
//================================================
void FT_Setup()
{
  hat.Begin=0xAAAA;
  hat.Cpt=500;
  hat.End=0x5555;
}
//================================================
#if (BATTERY_CONTROL != 0) && (OUTPUT__HAS_RN_BLUETOOTH != 0)
	float	Uprev = 0.0; 
	char	flashcount;
	#define FlushBound		(1 << 6)
#endif
//------------------------------------------------
void FT_Data()
{
	#if (BATTERY_CONTROL != 0) && (OUTPUT__HAS_RN_BLUETOOTH != 0)
		float Ubat = float(analogRead(Battary_ADC_pin));
		if (Uprev == 0) Uprev = Ubat;
		Uprev = Ubat * Alpha + Uprev * ( 1.0f - Alpha );
		Ubat = round(Uprev) * ((Rminus + Rplus) / Rminus * Uref * 100.0f / 1023.0f);
		hat.Cpt = int16_t(Ubat);

		++flashcount &= (FlushBound - 1);
		if (hat.Cpt < (round(Umin * 100)) )
		{
			// flashing LED
			digitalWrite(STATUS_LED_PIN, ((FlushBound >> 1) & flashcount) );
		}
		else
		{
			//if 5DOF --> LED turn on
			digitalWrite(STATUS_LED_PIN, NeckConnected);
		}
	#else																						// BATTERY_CONTROL == 0
		hat.Cpt++;  if (hat.Cpt>999) { hat.Cpt=500; };
	#endif

	hat.YPR[0] = YPR_head[0];
	hat.YPR[1] = YPR_head[1];
	hat.YPR[2] = YPR_head[2];
	
	hat.XYZ[0] = Shift[0];
	hat.XYZ[1] = Shift[1];
	hat.XYZ[2] = Shift[2];
	
  Serial.write((byte*)&hat,30);
}
//==============================================================================
