//=====================================
#ifndef	ReadSensors_cpp
#define ReadSensors_cpp
//======================================
//================================================
void Acc2PitchRoll(float acc[3], float &pitch, float &roll)
{
  // GET PITCH
  // Using y-z-plane-component/x-component of gravity vector
  pitch = -atan2(acc[0], sqrt(acc[1] * acc[1] + acc[2] * acc[2]));
  // GET ROLL
  // Compensate pitch of gravity vector 
  float temp1[3];
  float temp2[3];
  float xAxis[] = {1.0f, 0.0f, 0.0f};
  Vector_Cross_Product(temp1, acc, xAxis);
  Vector_Cross_Product(temp2, xAxis, temp1);
  // Normally using x-z-plane-component/y-component of compensated gravity vector
  // roll = atan2(temp2[1], sqrt(temp2[0] * temp2[0] + temp2[2] * temp2[2]));
  // Since we compensated for pitch, x-z-plane-component equals z-component:
  roll  =  atan2(temp2[1], temp2[2]);
}
//------------------------------------------------
// Apply calibration to vector of Gyro
void compensate(float vector[3], const byte mode, const float center[3])
{
	if (mode != none) for (int i = 0; i < 3; i++) vector[i] -= center[i];
}
//------------------------------------------------
// Apply calibration to vector of Mag and Acc sensor
void compensate(float vector[3], const byte mode, const float center[3], const float matrix[3][3])
{
	float tmp[3];
	if (mode == extended) {
    for (int i = 0; i < 3; i++) tmp[i] = vector[i] - center[i];
    Matrix_Vector_Multiply(matrix, tmp, vector);
	} else if (mode == standard) {
    for (int i = 0; i < 3; i++) vector[i] = (vector[i] - center[i]) * matrix[i][i];
	}
}
//------------------------------------------------
// Apply calibration to raw sensor readings
void compensate_sensor_errors() {
	// --- compensate Head sensors: ---
	compensate(mag_head, Calibr.D.mag_mode,  Calibr.D.mag_center, Calibr.D.mag_matrix);
	compensate(acc_head, Calibr.D.acc_mode,  Calibr.D.acc_center, Calibr.D.acc_matrix);
	compensate(gyr_head, Calibr.D.gyr_mode,  Calibr.D.gyr_center);

	if (NeckConnected)
	{
		// --- compensate Neck sensors: ---
		compensate(acc_neck, Calibr.D.accN_mode, Calibr.D.accN_center, Calibr.D.accN_matrix);
		compensate(gyr_neck, Calibr.D.gyrN_mode, Calibr.D.gyrN_center);
	}
}
//------------------------------------------------
// Read every sensor and record a time stamp
// Init DCM with unfiltered orientation
void reset_sensor_fusion() {

	#if defined Kp_YAW
		#if defined Ki_YAW
		float yaw;
		#endif
	#endif
	float pitch;
	float roll;

	Sensor.Read(gyr_head, acc_head, mag_head);
	if (NeckConnected) Sensor_neck.Read(gyr_neck, acc_neck, mag_neck);
  timestamp = micros();
	compensate_sensor_errors();	// Apply sensor calibration

	Acc2PitchRoll(acc_head, pitch, roll);
  
  // Init rotation matrix without yaw
  Init_rotation_matrix(DCM_head, 0.0f,   pitch, roll);
  // GET YAW
	#if defined Kp_YAW
		#if defined Ki_YAW
			Compass_Heading();
			yaw = MAG_Heading;
			// Init rotation matrix with yaw
			Init_rotation_matrix(DCM_head, yaw, pitch, roll);
		#endif
	#endif

	//--- neck ---
	if (NeckConnected)
	{
		float pitchN;
		float rollN;
		Acc2PitchRoll(acc_neck, pitchN, rollN);
		Init_rotation_matrix(DCM_neck, 0.0f, pitchN, rollN);
	}

	NullVector(Omega_P_head);
	NullVector(Omega_I_head);
	NullVector(Omega_P_neck);
	NullVector(Omega_I_neck);
}
//------------------------------------------------
void NullNeck()
{
	NullVector(gyr_neck);
	NullVector(acc_neck);
	NullVector(mag_neck);
}
//================================================
#endif	/* ReadSensors_cpp */
