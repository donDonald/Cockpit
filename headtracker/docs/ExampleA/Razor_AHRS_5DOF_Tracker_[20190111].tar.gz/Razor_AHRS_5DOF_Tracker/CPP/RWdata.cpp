/* This file is part of the Razor AHRS Firmware */
//================================================
#include <EEPROM.h>

#define CSkey							(0x55)
#define CalibrSize 				( 199)
#define AdrCalibr					( 128 ) 
#define AdrCenter					(AdrCalibr + CalibrSize) 
#define TimeOut						( 500)
//===============================================
// Blocks for 50 mS until another byte is available on serial port
char readChar()
{
	long time0 = millis();
	while (Serial.available() == 0) if ((millis() - time0) >= 50) return(0xFF);
	return(Serial.read());
}
//===============================================
byte IsEEpromError()
{
	byte CS = CSkey;
	for (int i = 0; i < (CalibrSize-1); i++) CS += EEPROM[(int)AdrCalibr + i];
	return(CS != EEPROM[(int)AdrCalibr + (int)CalibrSize - 1]);
}
//-----------------------------------------------
void CheckEEprom()
{
	Serial.write(IsEEpromError());
}
//-----------------------------------------------
void EEprom2RAM()
{
	if (!IsEEpromError()) EEPROM.get((int)AdrCalibr, Calibr);
}
//-----------------------------------------------
void EEprom2Serial()
{
	EEprom2RAM();
	Serial.write(Calibr.B, CalibrSize);
}
//-----------------------------------------------
void Center2Serial()
{
	Serial.write((byte*) &Center, (4+36+36));		// binary
}
//-----------------------------------------------
void Serial2EEprom()
{
	for (int i = 0; i < CalibrSize; i++)
	{
		unsigned long time0 = millis();
		while (Serial.available() == 0) if ((millis() - time0) >= TimeOut) goto RX_error;
		Calibr.B[i] = Serial.read();
	};
	EEPROM.put((int)AdrCalibr, Calibr);
	delay(200);
	CheckEEprom();
	return;

RX_error:
	Serial.write(CSkey);
}
//-----------------------------------------------
void EraseEEprom()
{
	for (int i = 0; i < ((int)AdrCenter + (int)sizeof(Center)); i++)
		EEPROM.put(i,  0xFF);
	Serial.write(CSkey);
}
//-----------------------------------------------
void SaveCenter()
{
	EEPROM.put((int)AdrCenter,  Center);
}
//-----------------------------------------------
void LoadCenter()
{
	EEPROM.get((int)AdrCenter,  Center);
}
//===============================================
