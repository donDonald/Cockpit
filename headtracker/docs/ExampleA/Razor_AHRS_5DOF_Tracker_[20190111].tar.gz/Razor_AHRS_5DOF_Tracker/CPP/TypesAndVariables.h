//=====================================
#ifndef	TypesAndVariables_h
#define TypesAndVariables_h
//======================================
#define STATUS_LED_PIN 13								// Pin number of status LED
#define TO_RAD(x) (x * (PI / 180.0))
#define TO_DEG(x) (x * (180.0 / PI))
//--------------------------------------
#define none			0
#define standard	1
#define extended	2
/*****************************************************************/
// OUTPUT OPTIONS
/*****************************************************************/
// Sensor data output interval in microseconds
// This may not work, if faster than 20000us (=50Hz)
// Code is tuned for 20000us, so better leave it like that
#define OUTPUT__DATA_INTERVAL 20000UL  // in microseconds

// Output mode definitions (do not change)
#define OUTPUT__MODE_ANGLES 						1 // Outputs yaw/pitch/roll in degrees
#define OUTPUT__MODE_SENSORS_CALIB 			2	// Outputs calibrated sensor values for all 9 axes
#define OUTPUT__MODE_SENSORS_RAW 				3	// Outputs raw (uncalibrated) sensor values for all 9 axes
// Output format definitions (do not change)
#define OUTPUT__FORMAT_TEXT 						1 // Outputs data as text
#define OUTPUT__FORMAT_BINARY 					2 // Outputs data as binary float
#define OUTPUT__FORMAT_FACETRACK 				3 // Outputs data to facetrack

boolean output_stream_on;
boolean output_single_on;

// Dont change startup output mode and format for working of OpenTrack!
int output_mode	 = OUTPUT__MODE_ANGLES;
int output_format = OUTPUT__FORMAT_FACETRACK;

//================================================================/
// Bluetooth options
/*****************************************************************/
// if defined OUTPUT__HAS_RN_BLUETOOTH == 1
// and Arduino has ATmega32U4 chip,
// output data will flows through Serial1,
// for correct working with Bluetooth unit
//================================================================/
#if OUTPUT__HAS_RN_BLUETOOTH != 0
	#if defined (__AVR_ATmega32U4__)
		#define Serial Serial1
	#endif
#endif
/*****************************************************************/

//======================================
struct tCalibr
{
	byte	YY,MM,DD,hh,mm;									//  5

	byte	mag_mode;													//  1
	float mag_center[3];										// 12
	float mag_matrix[3][3];								// 36
	byte	acc_mode;													//  1
	float acc_center[3];										// 12
	float acc_matrix[3][3];								// 36
	byte	gyr_mode;													//  1
	float gyr_center[3];										// 12
	byte	center_mode;											//  1
	char	orient_matrix[3][3];							//	9		//121 bytes

	byte	accN_mode;												//  1
	float accN_center[3];									// 12
	float accN_matrix[3][3];								// 36
	byte	gyrN_mode;												//  1
	float gyrN_center[3];									// 12
	byte	centerN_mode;										//  1
	char	orientN_matrix[3][3];						//	9		//72 bytes

	byte  CS;																//  1						
};				 																//= 5 + 121 + 72 + 1 = 199 bytes
//--------------------------------------
union tUnionCalibr
{
	tCalibr D;
	byte B[sizeof(tCalibr)];
};
//--------------------------------------
tUnionCalibr Calibr {
	// -- YY/MM/DD hh:mm: ----------------
			0x19, 0x01, 0x07, 0x12, 0x34,
	// -- mag_mode: ----------------------
			extended,
	// -- mag_center[3]: -----------------
			0,  0,  0,
	// -- mag_matrix[3][3]: --------------
		  1,  0,  0,
			0,  1,  0,
			0,  0,  1,

	// -- acc_mode: ----------------------
			standard,
	// -- acc_center[3]: -----------------
			0,  0,  0,
	// -- acc_matrix[3][3]: --------------
		  1,  0,  0,
			0,  1,  0,
			0,  0,  1,
	// -- gyr_mode: ----------------------
			standard,
	// -- gyr_center[3]: -----------------
			0,  0,  0,
	// -- center_mode: -------------------
			standard,
	// -- orient_matrix[3][3]: -----------
			1,  0,  0,
			0,  1,  0,
			0,  0,  1,

	// -- accN_mode: ---------------------
			standard,
	// -- accN_center[3]: ----------------
			0,  0,  0,
	// -- accN_matrix[3][3]: -------------
		  1,  0,  0,
			0,  1,  0,
			0,  0,  1,
	// -- gyrN_mode: ---------------------
			standard,
	// -- gyrN_center[3]: ----------------
			0,  0,  0,
	// -- centerN_mode: ------------------
			standard,
	// -- orientN_matrix[3][3]: ----------
			1,  0,  0,
			0,  1,  0,
			0,  0,  1,
	// -- CS: ----------------------------
			0x00 };	// Control Sum
//======================================
struct tCenter
{
	float ZeroYaw;
	float Matrix[3][3];
	float MatrixN[3][3];
};																				//size = 76 bytes
//--------------------------------------
tCenter Center;
//======================================
float& mag_x_scale = Calibr.D.mag_matrix[0][0];
float& mag_y_scale = Calibr.D.mag_matrix[1][1];
float& mag_z_scale = Calibr.D.mag_matrix[2][2];
//======================================

//=========== Head variables ===========
float mag_head[3];
float acc_head[3];  // Actually stores the NEGATED acceleration (equals gravity, if board not moving).
float gyr_head[3];
float MAG_Heading;
float DCM_head[3][3];

float OutputMatrixHead[3][3];
float OutputMatrixNeck[3][3];

char	NeckConnected	= false;

#define  MaxShift  30.0f
float YPR_head[3];
float YPR_neck[3];
float Shift[3];

GY521 Sensor_neck;

//========== Neck variables ============
float mag_neck[3];
float acc_neck[3];
float gyr_neck[3];
float DCM_neck[3][3];

float Omega_P_head[3];			// Omega Proportional correction
float Omega_I_head[3];			// Omega Integrator

float Omega_P_neck[3];			// Omega Proportional correction
float Omega_I_neck[3];			// Omega Integrator

// DCM timing in the main loop
unsigned long timestamp;
unsigned long timestamp_old;
float G_Dt;									// Integration time for DCM algorithm
//======================================
#endif	/* TypesAndVariables_h */
