/* This file is part of the Razor AHRS Firmware */
//**************************************************/

/**************************************************/
// DCM algorithm
//==================================================
void Matrix_update(float gyr[3], float DCM[3][3], float OmegaP[3], float OmegaI[3])
{
	float Omega_Vector[3];												// Corrected gyr data
	float Omega[3];
  Vector_Add(Omega, gyr, OmegaI);							//adding Integrator term
  Vector_Add(Omega_Vector, Omega, OmegaP);		//adding Proportional term
  
	float Update_Matrix[3][3];										//antisymmetric matrix
  Update_Matrix[0][0]= 0;
  Update_Matrix[0][1]=-G_Dt*Omega_Vector[2];	//-z
  Update_Matrix[0][2]= G_Dt*Omega_Vector[1];	// y
  Update_Matrix[1][0]= G_Dt*Omega_Vector[2];	// z
  Update_Matrix[1][1]= 0;
  Update_Matrix[1][2]=-G_Dt*Omega_Vector[0];	//-x
  Update_Matrix[2][0]=-G_Dt*Omega_Vector[1];	//-y
  Update_Matrix[2][1]= G_Dt*Omega_Vector[0];	// x
  Update_Matrix[2][2]= 0;

	float M[3][3];
  Matrix_Multiply(DCM, Update_Matrix, M);			//a*b=c
  for(int x=0; x<3; x++)												//adding Integrator term
		Vector_Add(DCM[x], DCM[x], M[x]);
}
//==================================================
void Normalize(float DCM[3][3])
{
  float error;
  float M[3][3];
  error= -Vector_Dot_Product(DCM[0],DCM[1])*.5;			//eq.19
  Vector_Scale(M[0], DCM[1], error);									//eq.19
  Vector_Scale(M[1], DCM[0], error);									//eq.19
  
  Vector_Add(M[0], M[0], DCM[0]);											//eq.19
  Vector_Add(M[1], M[1], DCM[1]);											//eq.19
  
  Vector_Cross_Product(M[2],M[0],M[1]);	// c= a x b 	//eq.20
  
  float renorm;
  renorm= .5 *(3 - Vector_Dot_Product(M[0],M[0]));		//eq.21
  Vector_Scale(DCM[0], M[0], renorm);
  
  renorm= .5 *(3 - Vector_Dot_Product(M[1],M[1]));		//eq.21
  Vector_Scale(DCM[1], M[1], renorm);
  
  renorm= .5 *(3 - Vector_Dot_Product(M[2],M[2]));		//eq.21
  Vector_Scale(DCM[2], M[2], renorm);
}
//==================================================
//Compensation the Roll and Pitch drift.
void Drift_correction_RollPitch(float acc[3], float DCM[3][3], float OmegaP[3], float OmegaI[3])
{
	float Accel_weight = Weight(acc);

	float errorRollPitch[3];
  Vector_Cross_Product(errorRollPitch, acc, DCM[2]);
  Vector_Scale(OmegaP, errorRollPitch, Kp_ROLLPITCH * Accel_weight);
  
  float Scaled_Omega_I[3];
  Vector_Scale(Scaled_Omega_I, errorRollPitch, Ki_ROLLPITCH * Accel_weight);
  Vector_Add(OmegaI, OmegaI, Scaled_Omega_I);     
}  
//==================================================
#if defined Kp_YAW
	#if defined Ki_YAW
void Compass_Heading()
{
	float	pitch;
	float	roll;
  float mag_x;
  float mag_y;
  float cos_roll;
  float sin_roll;
  float cos_pitch;
  float sin_pitch;
  
	pitch     = -asin(DCM_head[2][0]);
	roll      = atan2(DCM_head[2][1], DCM_head[2][2]);
  sin_roll  = sin(roll);
  cos_roll  = cos(roll);
  sin_pitch = sin(pitch);
  cos_pitch = cos(pitch);

  // Tilt compensated magnetic field X
  mag_x = mag_head[0] * cos_pitch + mag_head[1] * sin_roll * sin_pitch + mag_head[2] * cos_roll * sin_pitch;
  // Tilt compensated magnetic field Y
  mag_y = mag_head[1] * cos_roll - mag_head[2] * sin_roll;
  // Magnetic Heading
  MAG_Heading = atan2(-mag_y, mag_x);
}
	#endif
#endif
//==================================================
#if defined Kp_YAW
	#if defined Ki_YAW
void Drift_correction_Yaw_Head()	// for Head
{
  float mag_heading_x = cos(MAG_Heading);
  float mag_heading_y = sin(MAG_Heading);

  float errorCourse=(DCM_head[0][0]*mag_heading_y) - (DCM_head[1][0]*mag_heading_x);  //Calculating YAW error
	float errorYaw[3];
  Vector_Scale(errorYaw,DCM_head[2],errorCourse); //Applys the yaw correction to the XYZ rotation of the aircraft, depeding the position.
  
  float Scaled_Omega_P[3];
  Vector_Scale(Scaled_Omega_P, errorYaw, Kp_YAW);	//.01 proportional of YAW.
  Vector_Add(Omega_P_head, Omega_P_head, Scaled_Omega_P);		//Adding  Proportional.
  
  float Scaled_Omega_I[3];
  Vector_Scale(Scaled_Omega_I, errorYaw, Ki_YAW);	//.00001 Integrator
  Vector_Add(Omega_I_head, Omega_I_head, Scaled_Omega_I);		//adding integrator to the Omega_I
}
	#endif
#endif
//==================================================
//Compensation the Roll, Pitch and Yaw drift.
void Drift_correction_Yaw_Neck()	// for Neck
{
	#define _Kp_YAW 1.2f
	#define _Ki_YAW 0.00002f
  float errorCourse= - DCM_neck[1][0];  //Calculating YAW error
	float errorYaw[3];
  Vector_Scale(errorYaw,DCM_neck[2],errorCourse); //Applys the yaw correction to the XYZ rotation of the aircraft, depeding the position.

  float Scaled_Omega_P[3];
  Vector_Scale(Scaled_Omega_P, errorYaw, _Kp_YAW);	//.01 proportional of YAW.
  Vector_Add(Omega_P_neck, Omega_P_neck, Scaled_Omega_P);		//Adding  Proportional.
  
  float Scaled_Omega_I[3];
  Vector_Scale(Scaled_Omega_I, errorYaw, _Ki_YAW);	//.00001 Integrator
  Vector_Add(Omega_I_neck, Omega_I_neck, Scaled_Omega_I);		//adding integrator to the Omega_I
}
//==================================================

