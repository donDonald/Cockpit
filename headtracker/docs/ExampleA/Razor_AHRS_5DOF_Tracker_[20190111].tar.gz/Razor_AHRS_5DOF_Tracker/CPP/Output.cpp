/* This file is part of the Razor AHRS Firmware */
//==============================================//
#define Sinchro ("#")
void TXsinchro(char Mode)
{
	Serial.print(Sinchro);
	Serial.print(Mode);
}
//================================================
float Limit(float R, float Lim)
{
  if (R >  Lim) return( Lim);
  if (R < -Lim) return(-Lim);
	return(R);
}
//================================================
void Angles()
{
	float M[3][3];
	float yaw;
	
	//--- head angles: ---
	if (Calibr.D.center_mode == 0)
	{
		Matrix_Multiply(DCM_head, Calibr.D.orient_matrix, OutputMatrixHead); //a*b=c
		yaw = TO_DEG(atan2(OutputMatrixHead[1][0], OutputMatrixHead[0][0])) - Center.ZeroYaw;
   	if (yaw > +180) yaw = yaw - 360;
		else
   	if (yaw < -180) yaw = yaw + 360;
	}
	else
	{
		Matrix_Multiply(Center.Matrix, DCM_head, M); //a*b=c
		Matrix_Multiply(M, Calibr.D.orient_matrix, OutputMatrixHead); //a*b=c
		yaw = TO_DEG(atan2(OutputMatrixHead[1][0], OutputMatrixHead[0][0]));
	}

  YPR_head[0] = yaw;
  YPR_head[1] = TO_DEG(-asin(OutputMatrixHead[2][0]));
  YPR_head[2] = TO_DEG(-atan2(OutputMatrixHead[2][1], OutputMatrixHead[2][2]));
	//--- neck angles: ---
	if (NeckConnected)
	{
		if (Calibr.D.centerN_mode == 0)
		{
			Matrix_Multiply(DCM_neck, Calibr.D.orientN_matrix, OutputMatrixNeck); //a*b=c
		}
		else
		{
			Matrix_Multiply(Center.MatrixN, DCM_neck, M);										//a*b=c
			Matrix_Multiply(M, Calibr.D.orientN_matrix, OutputMatrixNeck);	//a*b=c
		}
		YPR_neck[0] = TO_DEG(atan2(OutputMatrixNeck[1][0], OutputMatrixNeck[0][0]));
		YPR_neck[1] = TO_DEG(-asin(OutputMatrixNeck[2][0]));
		YPR_neck[2] = TO_DEG(-atan2(OutputMatrixNeck[2][1], OutputMatrixNeck[2][2]));
	}
	else
	{
		NullVector(YPR_neck);
	}
}

//================================================
void Shifts()
{
	float x = OutputMatrixNeck[2][1];  //roll
	float y = OutputMatrixNeck[2][0];  //pitch

  Shift[0] = Limit((MaxShift  * 4.0f / PI) * -asin(x), MaxShift);
  Shift[1] = 0.0f;
  Shift[2] = Limit((MaxShift  * 4.0f / PI) * -asin(y), MaxShift);
}
//================================================
// Output angles: yaw, pitch, roll
void output_angles()
{
	if (output_format == OUTPUT__FORMAT_FACETRACK)
	{
		FT_Data();
	}
  else
	{
		if (output_format == OUTPUT__FORMAT_BINARY)
		{
			// TXsinchro('A');														//disconnected by Spanfro123
			Serial.write((byte*) YPR_head, 12);
		}
		else if (output_format == OUTPUT__FORMAT_TEXT)
		{
			Serial.print("#YPR=\t");
			Serial.print(YPR_head[0]); Serial.print(",\t");
			Serial.print(YPR_head[1]); Serial.print(",\t");
			Serial.print(YPR_head[2]); Serial.println();
		}
	}
}

//================================================
void output_sensors_text(char raw_or_calibrated)
{
  Serial.print("#A-"); Serial.print(raw_or_calibrated); Serial.print("=\t");
  Serial.print(acc_head[0]); Serial.print(",\t");
  Serial.print(acc_head[1]); Serial.print(",\t");
  Serial.print(acc_head[2]); Serial.println();

  Serial.print("#M-"); Serial.print(raw_or_calibrated); Serial.print("=\t");
  Serial.print(mag_head[0]); Serial.print(",\t");
  Serial.print(mag_head[1]); Serial.print(",\t");
  Serial.print(mag_head[2]); Serial.println();

  Serial.print("#G-"); Serial.print(raw_or_calibrated); Serial.print("=\t");
  Serial.print(TO_DEG(gyr_head[0])); Serial.print(", ");
  Serial.print(TO_DEG(gyr_head[1])); Serial.print(", ");
  Serial.print(TO_DEG(gyr_head[2])); Serial.println();
	
	Serial.println();
}

//================================================
void output_sensors_binary(char Mode)
{
	TXsinchro(Mode);											// 2 bytes

  Serial.write((byte*) mag_head, 12);
  Serial.write((byte*) acc_head, 12);
  Serial.write((byte*) gyr_head, 12);

  Serial.write((byte*) mag_neck, 12);
  Serial.write((byte*) acc_neck, 12);
  Serial.write((byte*) gyr_neck, 12);

  Serial.write((byte*) &G_Dt, 4);
}																				//2+36+36+4 = 78 bytes

//================================================
void output_sensors()
{
	char Prefix = 'R';
  if (output_mode == OUTPUT__MODE_SENSORS_CALIB)
	{
		Prefix = 'C';
		compensate_sensor_errors();
	}

	if (output_format == OUTPUT__FORMAT_BINARY)
		output_sensors_binary(Prefix);
	else if (output_format == OUTPUT__FORMAT_TEXT)
		output_sensors_text(Prefix);
}

//================================================
void output_float(float T)
{
	if (output_format == OUTPUT__FORMAT_TEXT)
		Serial.println(T);							// text
	else
		Serial.write((byte*) &T, 4);		// binary
}
//================================================
