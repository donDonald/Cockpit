/*   This file is part of the Razor AHRS Firmware    */

/*=============== BATTERY_CONTROL ====================\
|       For usage of Battery Control connect          |
|       to Arduino 2 resistors:                       |
|       ---------------------------------------       |
|       Для использования контроля Батареи            |
|       подключите к Ардуино 2 резистора:             |
|       ---------------------------------------       |
|           GND            A3            VCC          |
|            |             |             |            |
|             --{R=10kOm}--*--{R=30kOm}--             |
\----------------------------------------------------*/

/*=============== BATTERY_CONTROL ====================\
|       If you are not using battery control,         |
|       replace 1 with 0 in the following line:       |
|       ---------------------------------------       |
|       Если вы не используете контроль батареи,      |
|        замените 1 на 0 в следующей строке:          |
\----------------------------------------------------*/
   #define BATTERY_CONTROL	1

// Arduino pin, which is connected to a battery divider:
// Вывод Arduino, который подключен к резистивному делителю батареи:
   #define Battary_ADC_pin A3

// Resistor between Arduino pin (A3) and GND   (10 kOm):
// Резистор между контактом Arduino (A3) и GND (10 kOm):
   #define Rminus 10.0

// Resistor between Arduino pin (A3) and VCC   (30 kOm):
// Резистор между контактом Arduino (A3) и VCC (30 kOm):
   #define Rplus  30.0

// ATmega Reference Internal Voltage    (1.1 Volt):
// Опорное внутреннее напряжение ATmega (1,1 Вольт):
   #define Uref    1.1

// Smoothing coefficient of exponential filter:
// Коэффициент сглаживания экспоненциального фильтра:
   #define Alpha   0.1

// Battery voltage, below which the PIN13 Arduino LED will blink (3,6 Volts):
// Напряжение батареи, ниже которого будет мигать светодиод PIN13 Arduino (3,6 Вольт):
   #define Umin		3.60
/*================ BATTERY.H END ====================*/
