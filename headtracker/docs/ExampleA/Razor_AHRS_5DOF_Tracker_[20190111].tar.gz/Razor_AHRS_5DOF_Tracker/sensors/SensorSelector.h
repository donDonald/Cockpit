//=====================================
#ifndef	SensorSelector_h
#define SensorSelector_h
//=====================================
#if   SensorVariant == 1
	#include "_SEN-10125.h"
	SEN_10125 	Sensor;
#elif SensorVariant == 2
	#include "_GY-85-hmc.h"
	GY85      	Sensor;
#elif SensorVariant == 3
	#include "_SEN-10321.h"
	SEN_10321 	Sensor;
#elif SensorVariant == 4
	#include "_SEN-10321.h"
	SEN_10321 	Sensor;
#elif SensorVariant == 5
	#include "_SEN-10724.h"
	SEN_10724 	Sensor;
#elif SensorVariant == 6
	#include "_GY-521.h"
	GY521     	Sensor;
#elif SensorVariant == 7
	#include "_GY521-GY271.h"
	GY521_GY271	Sensor;
#elif SensorVariant == 8
	#include "_GY-9250.h"
	MPU9250   	Sensor;
#elif SensorVariant == 9
	#include "_GY-85-QMC.h"
	GY85QMC   	Sensor;
#elif SensorVariant == 10
	#include "_GY-91.h"
	GY91   			Sensor;
#elif SensorVariant == 11
	#include "_GY521-GY273.h"
	GY521_GY273	Sensor;
#elif SensorVariant == 12
	#include "_GY521-gy271-qmc.h"
	GY521_GY271_qmc	Sensor;
#elif SensorVariant == 13
	#include "_GY521-GY273-qmc.h"
	GY521_GY273_qmc	Sensor;
#else
  #error YOU MUST TO SELECT THE SensorVariant FROM 1 TO 13! See "SENSOR SELECTOR" at top of "MENU.h" !
#endif
//=====================================
#endif	/* SensorSelector_h */

