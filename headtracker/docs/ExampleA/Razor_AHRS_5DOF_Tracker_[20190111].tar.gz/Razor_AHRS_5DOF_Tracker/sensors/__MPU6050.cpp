//======================================
#ifndef	MPU6050_cpp
#define MPU6050_cpp

#include <Arduino.h>
#include "__I2C.cpp"
//======================================
// DCM parameters:
#define Kp_ROLLPITCH (0.02f    * 256.0f)
#define Ki_ROLLPITCH (0.00002f * 256.0f)
//======================================
#define MPU6050_ADDRESS 		0x68					// Device address when ADO = 0

#define _CLOCK_PLL_XGYRO		0x01

#define _SMPLRT_DIV        0x19
#define _CONFIG            0x1A
#define _GYRO_CONFIG       0x1B
#define _ACCEL_CONFIG      0x1C
#define _ACCEL_CONFIG2     0x1D

#define _INT_PIN_CFG				0x37
#define _INT_ENABLE				0x38

#define _ACCEL_XOUT_H				0x3B
#define _ACCEL_XOUT_L				0x3C
#define _ACCEL_YOUT_H				0x3D
#define _ACCEL_YOUT_L				0x3E
#define _ACCEL_ZOUT_H				0x3F
#define _ACCEL_ZOUT_L				0x40

#define _TEMP_OUT_H					0x41
#define _TEMP_OUT_L					0x42

#define _GYRO_XOUT_H				0x43
#define _GYRO_XOUT_L       0x44
#define _GYRO_YOUT_H       0x45
#define _GYRO_YOUT_L       0x46
#define _GYRO_ZOUT_H       0x47
#define _GYRO_ZOUT_L       0x48

#define _PWR_MGMT_1					0x6B					// Device defaults to the SLEEP mode
//======================================
#define _GFS_250DPS					0x00					//  250DPS
#define _GFS_500DPS					0x01					//  500DPS
#define _GFS_1000DPS				0x02					// 1000DPS
#define _GFS_2000DPS				0x03					// 2000DPS

#define _AFS_2G							0x00					// +/- 2G
//--------------------------------------
#define _Gscale						_GFS_1000DPS			//maybe changed
#define _Ascale						_AFS_2G

#define _gRes (((float)(250L << _Gscale)/32768.0f) * (PI / 180.0f))	// for Rad/Sec
#define _aRes (2.0/32768.0)								// for Gravity = 1;
//======================================
class	MPU6050: 	virtual public I2C
{
protected:
	byte MPU6050_ADR;
	//------------------------------------
	byte MPU_Init(byte AD0 = 0)						//return 0 if error
	{
		MPU6050_ADR = MPU6050_ADDRESS + AD0;//AD0 = 0 or AD0 = 1
		byte erc = !I2Ccheck(MPU6050_ADR);
		if (!erc) return (erc);

		// Reset Gyro
		I2Cwrite(MPU6050_ADR, _PWR_MGMT_1, 0x80);
		delay(20);
		// Set_Clock PLL X
		I2Cwrite(MPU6050_ADR, _PWR_MGMT_1, _CLOCK_PLL_XGYRO);
		// Configure Gyro and Thermometer
		// Disable FSYNC and set thermometer and gyro bandwidth to 41 and 42 Hz, respectively; 
		// DLPF_CFG = bits 2:0 = 011; this limits the sample rate to 1000 Hz for both
		I2Cwrite(MPU6050_ADR, _CONFIG, 0x03);  
		// Set sample rate = gyroscope output rate/(1 + SMPLRT_DIV)
		I2Cwrite(MPU6050_ADR, _SMPLRT_DIV, 0x09);  // Use a 100 Hz rate; a rate consistent with the filter update rate 
		//set Full Scale Gyro Range
		I2Cwrite(MPU6050_ADR, _GYRO_CONFIG, (_Gscale << 3) );
		//set Full Scale Accel Range
		I2Cwrite(MPU6050_ADR, _ACCEL_CONFIG, (_Ascale << 3) );

		return (erc);
	};
	//------------------------------------
	byte ReadGyrBuf(byte buff[])
	{
		return (I2Cread(MPU6050_ADR, _GYRO_XOUT_H, 6, buff));
	};
	//------------------------------------
	byte ReadAccBuf(byte buff[])
	{
		return (I2Cread(MPU6050_ADR, _ACCEL_XOUT_H, 6, buff));
	};
	//------------------------------------
	byte ReadAccTemGyrBuf(byte buff[])
	{
		return (I2Cread(MPU6050_ADR, _ACCEL_XOUT_H, 6+2+6, buff));
	};
	//------------------------------------
public:
	//------------------------------------
	float ReadTemperature(void)						//temperature in degrees of Celsius
	{
		byte buf[2];
		I2Cread(MPU6050_ADR, _TEMP_OUT_H, 2, buf);
		float T = Bytes2Float(buf[0], buf[1]);
		T = (T + 521.0f) * (1.0f/ 340.0f) + 35.0f;				//convert to degrees of Celsius
		return (T);
	};
};	//class
//======================================
#endif	/* MPU6050_cpp */
