#include <Arduino.h>
//========================================
#ifndef	SENSOR_GY521
#define SENSOR_GY521
//--------- GY-521 (GY6050) --------------
#include "__MPU6050.cpp"
//========================================
class GY521: public MPU6050
{
public:
	//--------------------------------------
	byte Init(byte A0 = 0)
	{
		I2C_Init();
		return (MPU_Init(A0));
	};
	//--------------------------------------
	void Read(float G[],float A[],float M[])
	{
		byte buf[6+2+6]; 
		I2Cread(MPU6050_ADR, _ACCEL_XOUT_H, 6+2+6, buf);
		//Read_Acc(A);
		A[0] =  _aRes*Bytes2Float(buf[2], buf[3]);			// X axis (internal sensor y axis)
		A[1] =  _aRes*Bytes2Float(buf[0], buf[1]);			// Y axis (internal sensor x axis)
		A[2] =  _aRes*Bytes2Float(buf[4], buf[5]);			// Z axis (internal sensor z axis)
		//Read_Gyr(G);
		G[0] = -_gRes*Bytes2Float(buf[8+2],buf[8+3]);	// X axis (internal sensor -y axis)
		G[1] = -_gRes*Bytes2Float(buf[8+0],buf[8+1]);	// Y axis (internal sensor -x axis)
		G[2] = -_gRes*Bytes2Float(buf[8+4],buf[8+5]);	// Z axis (internal sensor -z axis)
		//Read_Mag(M);
		for (int i=0; i<3; i++) M[i] = 0.0f;					//dummy
	};
	//--------------------------------------
	float ReadPressure(void){ return(0.0f); }	//dummy pressure
	//--------------------------------------
};
//========================================
#endif	/* SENSOR_GY521 */

