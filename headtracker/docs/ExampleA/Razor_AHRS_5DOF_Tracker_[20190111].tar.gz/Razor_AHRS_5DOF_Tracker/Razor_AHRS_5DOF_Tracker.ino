/***************************************************************************************************************
* Razor AHRS 5DOF Tracker firmware version [20190111]

/=========================================================================\
| for update and for more information visit:                              |
| https://sites.google.com/site/diyheadtracking/                          |
| Email: go1@list.ru    GO63 Samara Russia 2019                           |
\=========================================================================/

* 9 Degree of Measurement Attitude and Heading Reference System
* for Sparkfun "9DOF Razor IMU" (SEN-10125 and SEN-10736)
* and "9DOF Sensor Stick" (SEN-10183, 10321 and SEN-10724)
*
* Released under GNU GPL (General Public License) v3.0
* Copyright (C) 2013 Peter Bartz [http://ptrbrtz.net]
* Copyright (C) 2011-2012 Quality & Usability Lab, Deutsche Telekom Laboratories, TU Berlin
*
* Infos, updates, bug reports, contributions and feedback:
*     https://github.com/ptrbrtz/razor-9dof-ahrs
*
*
* History:
*   * Original code (http://code.google.com/p/sf9domahrs/) by Doug Weibel and Jose Julio,
*     based on ArduIMU v1.5 by Jordi Munoz and William Premerlani, Jose Julio and Doug Weibel. Thank you!
*
*   * Updated code (http://groups.google.com/group/sf_9dof_ahrs_update) by David Malik (david.zsolt.malik@gmail.com)
*     for new Sparkfun 9DOF Razor hardware (SEN-10125).
*
*   * Updated and extended by Peter Bartz (peter-bartz@gmx.de):
*     * v1.3.0
*       * Cleaned up, streamlined and restructured most of the code to make it more comprehensible.
*       * Added sensor calibration (improves precision and responsiveness a lot!).
*       * Added binary yaw/pitch/roll output.
*       * Added basic serial command interface to set output modes/calibrate sensors/synch stream/etc.
*       * Added support to synch automatically when using Rovering Networks Bluetooth modules (and compatible).
*       * Wrote new easier to use test program (using Processing).
*       * Added support for new version of "9DOF Razor IMU": SEN-10736.
*       --> The output of this code is not compatible with the older versions!
*       --> A Processing sketch to test the tracker is available.
*     * v1.3.1
*       * Initializing rotation matrix based on start-up sensor readings -> orientation OK right away.
*       * Adjusted gyro low-pass filter and output rate settings.
*     * v1.3.2
*       * Adapted code to work with new Arduino 1.0 (and older versions still).
*     * v1.3.3
*       * Improved synching.
*     * v1.4.0
*       * Added support for SparkFun "9DOF Sensor Stick" (versions SEN-10183, SEN-10321 and SEN-10724).
*     * v1.4.1
*       * Added output modes to read raw and/or calibrated sensor data in text or binary format.
*       * Added static magnetometer soft iron distortion compensation
*     * v1.4.2
*       * (No core firmware changes)
*
* TODOs:
*   * Use self-test and temperature-compensation features of the sensors.
***************************************************************************************************************/
/*
  Axis definition (differs from definition printed on the board!):
    X axis pointing forward (towards the short edge with the connector holes)
    Y axis pointing to the right
    and Z axis pointing down.
    
  Positive yaw   : clockwise
  Positive roll  : right wing down
  Positive pitch : nose up
  
  Transformation order: first yaw then pitch then roll.
*/

/*
  Serial commands that the firmware understands:
  
  "#o<params>" - Set OUTPUT mode and parameters. The available options are:
  
      // Streaming output
      "#o0" - DISABLE continuous streaming output. Also see #f below.
      "#o1" - ENABLE continuous streaming output.
      
      // Output format
      "#ob" - Output angles in BINARY format (yaw/pitch/roll as binary float, so one output frame
              is 3x4 = 12 bytes long).
      "#ot" - Output angles in TEXT format (Output frames have form like "#YPR=-142.28,-5.38,33.52",
              followed by carriage return and line feed [\r\n]).
      "#of" - Output angles in FaceTrack format              

      // Sensor data output
      "#osct" - Output CALIBRATED SENSOR data of all 9 axes in TEXT format.
                One frame consist of three lines - one for each sensor: acc, mag, gyr.
      "#osrt" - Output RAW SENSOR data of all 9 axes in TEXT format.
                One frame consist of three lines - one for each sensor: acc, mag, gyr.
      "#oscb" - Output CALIBRATED SENSOR data of all 9 axes in BINARY format.
                One frame consist of three 3x3 float values = 36 bytes. Order is: acc x/y/z, mag x/y/z, gyr x/y/z.
      "#osrb" - Output RAW SENSOR data of all 9 axes in BINARY format.
                One frame consist of three 3x3 float values = 36 bytes. Order is: acc x/y/z, mag x/y/z, gyr x/y/z.
      
  "#f" - Request one output frame - useful when continuous output is disabled and updates are
         required in larger intervals only. Though #f only requests one reply, replies are still
         bound to the internal 20ms (50Hz) time raster. So worst case delay that #f can add is 19.99ms.
         
  "#s<xy>" - Request synch token - useful to find out where the frame boundaries are in a continuous
         binary stream or to see if tracker is present and answering. The tracker will send
         "#SYNCH<xy>\r\n" in response (so it's possible to read using a readLine() function).
         x and y are two mandatory but arbitrary bytes that can be used to find out which request
         the answer belongs to.
          
          
	// Information commands
  "#?v" - Read SensorVariant and sketch version 
  "#?t" - Read temperature       
  "#?p" - Read pressure

  // I2C direct commands
  "#?a" - Check I2C address 
  "#?r" - Read I2C [1..16 bytes]
  "#?w" - Write I2C byte

  // EEPROM commands
  "#w..." - Write data from Serial to RAM
  "#ew.." - Write from Serial to EEPROM... 
  "#er" - Read from EEPROM to Serial
  "#ec" - CheckEEprom
  "#ez" - Save center direction to EEPROM
  "#ee" - EraseEEprom

  // Centering commands
  "#Z0" - Select type of center_mode #Z0..#Z2
  "#or" - Reset  YPR for FaceTrack mode
  "#oz" - Center YPR for FaceTrack mode

  ("#C" and "#D" - Reserved for communication with optional Bluetooth module.)
  
  Newline characters are not required. So you could send "#ob#o1#s", which
  would set binary output mode, enable continuous streaming output and request
  a synch token all at once.
  
  The status LED will be ON if tracker in 5DOF mode and OFF in 3DOF mode.
  
  Byte order of binary output is little-endian: least significant byte comes first.
*/

/*****************************************************************/
#define  SketchVersion 20190111
/*****************************************************************/
#include "Menu.h"
#include "Battery.h"
//------------------------------------------------
#include "sensors\SensorSelector.h"
#include "sensors\_GY-521.h"
//------------------------------------------------
#include "cpp\TypesAndVariables.h"
#include "cpp\Math.cpp"
#include "cpp\Dcm.cpp"
#include "cpp\RWdata.cpp"
#include "cpp\FaceTrack.cpp"
#include "cpp\ReadSensors.cpp"
#include "cpp\Output.cpp"

/*================== Setup() function ====================\

 In the Setup() added output information in Serial about:
  - the current version of the sketch
  - the selected variant of Head sensor 
  - selected Bluetooth mode
  - current Baudrate
  - the process of initializing the sensor modules
  - current operation mode: 5DOF / 3DOF
 A typical output in the Port Monitor looks like this:
 ------------------------------------------------------
 В функцию Setup() добавлен вывод в Serial информации о:
  - текущей версии скетча
  - выбранном варианте сенсора Head
  - выборе Bluetooth
  - скорости обмена Baudrate
  - процесса инициализации модулей сенсоров
  - текущего режима работы: 5DOF/3DOF
 Типичный вывод в Мониторе Порта выглядит так:
 ------------------------------------------------------
  ...
  Razor AHRS 5DOF [20190111]
	
  SensorVariant   8
  Bluetooth       1
  BaudRate        57600

  BatteryControl  1
  Umin            3.60

  Head Sensor Init.. OK
  Neck Sensor Init.. OK, 5DOF mode

  Main loop:
	.................

\----------------------------------------------------*/
void setup()
{
  // Init serial output
  Serial.begin(OUTPUT__BAUD_RATE);
	while (!Serial);																		// Needed only for built-in USB ports.

	Serial.print  ( "\nRazor AHRS 5DOF [");	 Serial.print  (SketchVersion);	
	Serial.print  ("]\n\nSensorVariant   ");	 Serial.print  (SensorVariant);	
	Serial.print  ( "\nBluetooth       ");	 Serial.print  (OUTPUT__HAS_RN_BLUETOOTH);	
	Serial.print  ( "\nBaudRate        ");	 Serial.println(OUTPUT__BAUD_RATE);	

	#if BATTERY_CONTROL == 0
		Serial.print  ("\nBatteryControl  0\n");
	#else
		analogReference(INTERNAL);
		Serial.print  ("\nBatteryControl  1\nUmin            ");
		Serial.println(Umin);			
	#endif

	EEprom2RAM();																			//EEprom2Serial();
  pinMode (STATUS_LED_PIN, OUTPUT);									// Init status LED

  // Init sensors
	Serial.print  ("\nHead Sensor Init.. ");
	Sensor.Init();
	Serial.print  ("OK\nNeck Sensor Init.. ");	
	NeckConnected = Sensor_neck.Init(1);
	digitalWrite(STATUS_LED_PIN, NeckConnected);			//if 5DOF --> LED turn on
	if (NeckConnected)
	  Serial.println("OK, 5DOF mode");
	else
	  Serial.println("NO, 3DOF mode");
	
  // Read sensors, init DCM algorithm
	IdentityMatrix(DCM_head);
	IdentityMatrix(DCM_neck);
	LoadCenter();

  // Modified by Vitaly "MegaMozg" Naidentsev and "GO63"
	// for "Razor_AHRS"+"FaceTrack" compatibility
  FT_Setup();

  // Init output
	output_stream_on = true;
  reset_sensor_fusion();

  Serial.println("\nMain loop:\n");
}

//================================================
// Main loop
//------------------------------------------------
void loop()
{
  // Read incoming control messages
  if (Serial.available())
  {
    if (readChar() == '#') 							// Start of new control message
    {
      int command = readChar();	 				// Commands

      if (command == 'f') 								// request one output _f_rame
        output_single_on = true;

			else if (command == 's') 					// _s_ynch request
      {
        // Read ID
        byte id[2];
        id[0] = readChar();
        id[1] = readChar();
        
        // Reply with synch message
        Serial.print("#SYNCH");
        Serial.write(id, 2);
        Serial.println();
      }

      else if (command == 'o') 					// Set _o_utput mode
      {
        char output_param = readChar();
        if (output_param == 't') 				// Output angles as _t_ext
        {
          output_mode   = OUTPUT__MODE_ANGLES;
          output_format = OUTPUT__FORMAT_TEXT;
        }
        else if (output_param == 'b') 		// Output angles in _b_inary format
        {
          output_mode   = OUTPUT__MODE_ANGLES;
          output_format = OUTPUT__FORMAT_BINARY;
        }
        // Modified by Vitaly "MegaMozg" Naidentsev and "GO63"
				// for "Razor_AHRS"+"FaceTrack" compatibility
        else if (output_param == 'f') 		// Output angles in FACETRACK format
        {
          output_mode   = OUTPUT__MODE_ANGLES;
          output_format = OUTPUT__FORMAT_FACETRACK;
        }        
        else if (output_param == 's') 		// Output _s_ensor values
        {
          char values_param = readChar();
          char format_param = readChar();
          if (values_param == 'r')  			// Output _r_aw sensor values
            output_mode = OUTPUT__MODE_SENSORS_RAW;
          else if (values_param == 'c')	// Output _c_alibrated sensor values
            output_mode = OUTPUT__MODE_SENSORS_CALIB;
          if (format_param == 't') 			// Output values as _t_text
            output_format = OUTPUT__FORMAT_TEXT;
          else if (format_param == 'b') 	// Output values in _b_inary format
            output_format = OUTPUT__FORMAT_BINARY;
        }
        else if (output_param == '0') 		// Disable continuous streaming output
					output_stream_on = false;
        else if (output_param == '1') 		// Enable continuous streaming output
					output_stream_on = true;
				else if (output_param == 'z')		// #oz center YPR for FaceTrack mode
					FixCenter();
				else if (output_param == 'r')		// #or reset  YPR for FaceTrack mode
					ResetCenterMatrix();
      }

      else if (command == '?')
      {
        char param = readChar();
        if (param == 'v')								// #?v sensor variant and sketch version 
				{
					#if SensorVariant < 16
						Serial.print(0);
					#endif					
					Serial.print((byte)SensorVariant, HEX);
					Serial.print(SketchVersion);
					Serial.print(NeckConnected);
				}
				else if (param == 't')						// #?t read temperature
					output_float(Sensor.ReadTemperature());
				else if (param == 'p')						// #?p read pressure
					output_float(Sensor.ReadPressure());
				else if (param == 'a')						// #?a Check I2C
					Serial.write(Sensor.I2Ccheck(readChar()));
				else if (param == 'r')						// #?r Read I2C [1..16 bytes]
				{
					byte Buf[16];
					byte I2Cadr = readChar();
					byte Adr    = readChar();
					byte Num    = readChar();
					Num = Sensor.I2Cread(I2Cadr, Adr, Num, Buf);
					Serial.write(Buf, Num);
				}
				else if (param == 'w')						// #?w Write I2C
				{
					byte I2Cadr = readChar();
					byte Adr    = readChar();
					byte Data   = readChar();
					Serial.write(Sensor.I2Cwrite(I2Cadr, Adr, Data));
				}

			}

      else if (command == 'e')						// Read/Write eeprom data
      {
        char eeprom_command = readChar();
        if      (eeprom_command == 'w') Serial2EEprom();		//#ew...
				else if (eeprom_command == 'r') EEprom2Serial();		//#er
				else if (eeprom_command == 'c') CheckEEprom();			//#ec
				else if (eeprom_command == 'z') SaveCenter();				//#ez
				else if (eeprom_command == 'e') EraseEEprom();			//#ee
				else if (eeprom_command == 'R') reset_sensor_fusion();	//#eR
				else if (eeprom_command == 'C') Center2Serial();		//#eC
			}

      else if (command == 'w')						// #w write data to Calibr.B
      {
        byte adr = readChar();		//address of begin
        byte len = readChar();		//length
				for(byte i = 0; i < len; i++) Calibr.B[adr + i] = readChar();
			}

      else if (command == 'Z')						// Select type of center_mode #Z0..#Z2, #Z4..#Z6
      {
				char c = (readChar() & 0x07);
				if (c<4) Calibr.D.center_mode  = c;
				else     Calibr.D.centerN_mode = (c & 0x03);
			}

			#if OUTPUT__HAS_RN_BLUETOOTH == 1
      // Read messages from bluetooth module
      // For this to work, the connect/disconnect message prefix of the module has to be set to "#".
      else if (command == 'C') // Bluetooth "#CONNECT" message (does the same as "#o1")
				output_stream_on = true;
      else if (command == 'D') // Bluetooth "#DISCONNECT" message (does the same as "#o0")
				output_stream_on = false;
			#endif // OUTPUT__HAS_RN_BLUETOOTH == 1
    }
  }
	//-----------------------------------------------------------------------

	//-----------------------------------------------------------------------
  // Time to read the sensors again?
  if((micros() - timestamp) >= OUTPUT__DATA_INTERVAL)
  {
    timestamp_old = timestamp;
    timestamp = micros();
		G_Dt = (float) (timestamp - timestamp_old) * 1.0e-6; // Real time of loop run. We use this on the DCM algorithm (gyro integration time)
    // Update sensor readings
		Sensor.Read(gyr_head, acc_head, mag_head);
		if (NeckConnected)
		{
			Sensor_neck.Read(gyr_neck, acc_neck, mag_neck);
		}
		else
		{
			NullVector(gyr_neck);
			NullVector(acc_neck);
			NullVector(mag_neck);
		}
		
    if (output_mode == OUTPUT__MODE_ANGLES)								// Output angles
    {
			compensate_sensor_errors();
			Matrix_update(gyr_head, DCM_head, Omega_P_head, Omega_I_head);
			Normalize(DCM_head);
			Drift_correction_RollPitch(acc_head, DCM_head, Omega_P_head, Omega_I_head);
			#if defined Kp_YAW
				#if defined Ki_YAW
					Compass_Heading();
					Drift_correction_Yaw_Head();
				#endif
			#endif
			if (NeckConnected)
			{
				Matrix_update(gyr_neck, DCM_neck, Omega_P_neck, Omega_I_neck);
				Normalize(DCM_neck);
				Drift_correction_RollPitch(acc_neck, DCM_neck, Omega_P_neck, Omega_I_neck);
				Drift_correction_Yaw_Neck();
			}
			else
			{
				IdentityMatrix(DCM_neck);
			}
			Angles();
			Shifts();
			if (output_stream_on || output_single_on) output_angles();
    }
    else 																										// Output sensor values
    {      
      if (output_stream_on || output_single_on) output_sensors();
    }
    output_single_on = false;
  }
}
//================================================
